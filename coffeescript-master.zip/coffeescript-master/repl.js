module.exports = require('./lib/coffeescript/repl');
