## Chaining Function Calls

Leading `.` closes all open calls, allowing for simpler chaining syntax.

```
codeFor('chaining')
```
