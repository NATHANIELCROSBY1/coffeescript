## Unsupported ECMAScript Features

There are a few ECMAScript features that CoffeeScript intentionally doesn’t support.
