## Prototypal Inheritance

In addition to supporting ES2015 classes, CoffeeScript provides a shortcut for working with prototypes. The `::` operator gives you quick access to an object’s prototype:

```
codeFor('prototypes', '"one_two".dasherize()')
```
