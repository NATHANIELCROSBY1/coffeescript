## Screencasts

*   [A Sip of CoffeeScript](http://coffeescript.codeschool.com/) is a [Code School Course](https://www.codeschool.com) which combines 6 screencasts with in-browser coding to make learning fun. The first level is free to try out.
*   [Meet CoffeeScript](https://www.pluralsight.com/courses/meet-coffeescript) is a 75-minute long screencast by PeepCode, now [PluralSight](https://www.pluralsight.com/). Highly memorable for its animations which demonstrate transforming CoffeeScript into the equivalent JS.
*   If you’re looking for less of a time commitment, RailsCasts’ [CoffeeScript Basics](http://railscasts.com/episodes/267-coffeescript-basics) should have you covered, hitting all of the important notes about CoffeeScript in 11 minutes.
