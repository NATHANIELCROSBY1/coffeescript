require('./lib/coffeescript/register');
